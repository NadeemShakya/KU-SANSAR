<?php 

$to = "shakya.nadim12@gmail.com";
$message = "hello";
$subject = "Email Notification";
$header = "hello bro its me!";

$retval = mail($to, $subject, $message, $header);
if($retval == true){
	echo "message successful";
}else{
	echo "not successful";
}

 ?>