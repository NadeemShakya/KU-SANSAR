function selectDepartment(){
	var x = document.getElementById('selectDepartment').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectDepartment').style.fontSize = "15px";
	document.getElementById('selectDepartment').style.color = "red";


	if(y == 1){
		selectedDepartment = "CE";
	}else if(y == 2){
		selectedDepartment = "CV";
	}else if(y == 3){
		selectedDepartment = "EE"
	}
}

function selectYear(){
	var x = document.getElementById('selectYear').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectYear').style.fontSize = "15px";
	document.getElementById('selectYear').style.color = "red";
	if(y == 1){
		selectedYear = "first";

	}else if( y == 2){
		selectedYear = "second";
	}
}

function selectsemester(){
	var x = document.getElementById('selectSem').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectSem').style.fontSize = "15px";
	document.getElementById('selectSem').style.color = "red";
	if(y == 1){
		selectedSem = "first";

	}else if( y == 2){
		selectedSem = "second";
	}	
}



function openCalculator(){
	 if(selectedDepartment == "CE" && selectedYear == "first" && selectedSem == "first"){
		window.open("COMP1_1.html");
	}
	else if(selectedDepartment == "CE" && selectedYear == "first" && selectedSem == "second"){
		window.open("COMP1_2.html");
	}
	else if(selectedDepartment == "CE" && selectedYear == "second" && selectedSem == "first"){
		window.open("COMP2_1.html");
	}
	else if(selectedDepartment == "CE" && selectedYear == "second" && selectedSem == "second"){
		window.open("COMP2_2.html");
	}
	else if(selectedDepartment == "CV" && selectedYear == "first" && selectedSem == "first"){
		window.open("CIVIL1_1.html");
	}
	else if(selectedDepartment == "CV" && selectedYear == "first" && selectedSem == "second"){
		window.open("CIVIL1_2.html");
	}
	else if(selectedDepartment == "CV" && selectedYear == "second" && selectedSem == "first"){
		window.open("CIVIL2_1.html");
	}
	else if(selectedDepartment == "CV" && selectedYear == "second" && selectedSem == "second"){
		window.open("CIVIL2_2.html");
	}
	else if(selectedDepartment == "EE" && selectedYear == "first" && selectedSem == "first"){
		window.open("ELECT1_1.html");
	}
	else if(selectedDepartment == "EE" && selectedYear == "first" && selectedSem == "second"){
		window.open("ELECTI1_2.html");
	}
	else if(selectedDepartment == "EE" && selectedYear == "second" && selectedSem == "first"){
		window.open("ELECT2_1.html");
	}
	else if(selectedDepartment == "EE" && selectedYear == "second" && selectedSem == "second"){
		window.open("ELECT2_2.html");
	}
	


	
}