<?php 

	include 'dbh.php';
	session_start();
	if($_SERVER["REQUEST_METHOD"] == "POST"){
	$question = $_POST['post'];
	$studentID = $_SESSION['Student_ID'];
	$year = $_SESSION['year'];
	$semester = $_SESSION['semester'];
	$department = $_SESSION['department'];
	$subjectCode = $_POST['SubjectCode'];
	$subjectCodeUppercase = strtoupper($subjectCode);
	$times = date('h:m:sa');
	$date = date("y/m/d");
	date_default_timezone_set("Asia/Kathmandu");
	$time = date('h:i:sa');
	$dir = 'uploads/';
	$target_file = $dir . basename($_FILES['fileUpload']['name']);
	$filetype = pathinfo($target_file, PATHINFO_EXTENSION);
	$fileName = basename($_FILES['fileUpload']['name']);
	if($fileName != ""){
		if($filetype != 'jpg' && $filetype != "png" && $filetype != "jpeg" && $filetype != "gif"){
			echo "<script>alert('Invalid File Format! Try Again! Only images allowed!');</script>";
			header("Refresh:0.2; url = main.php");
		}

		else if(file_exists($target_file)){
			echo "<script>alert('Filename Already Exists! Try renaming the file and Try Again!');</script>";
			header("Refresh:0.2; url = main.php");
		}
		else if($_FILES['fileUpload']['size'] > 1000000){
			echo "<script>alert('File Too Large! Max : 1MB');</script>";
			header("Refresh:0.2; url = main.php");
		} // in bytes! i.e. 1MB
		else{

			$sql = "INSERT INTO Questions(Question, Student_ID, Dates, Subject_Code, file, Post_time) VALUES('$question', '$studentID', '$date', '$subjectCodeUppercase', '$fileName', '$time')";

			$result = mysqli_query($connection, $sql);
			move_uploaded_file($_FILES['fileUpload']['tmp_name'],$target_file);
			if($result){
				echo "<script>alert('Question Posted Successfully!');</script> ";
				header("Refresh:0.2; url = main.php");

			}else{
				echo "<script>alert('Question Not Posted');</script> ";
				header("Refresh:0.2; url = main.php");

			}


			header("Refresh:0.2;url = main.php");
		}
	}else{
		$sql = "INSERT INTO Questions(Question, Student_ID, Dates, Subject_Code, file, Post_time) VALUES('$question', '$studentID', '$date', '$subjectCodeUppercase', DEFAULT, '$time')";
			$result = mysqli_query($connection, $sql);

		if($result){
				echo "<script>alert('Question Posted Successfully!');</script> ";
				header("Refresh:0.2; url = main.php");

			}else{
				echo "<script>alert('Question Not Posted');</script> ";
				header("Refresh:0.2; url = main.php");

			}
	}

}
 ?>