      var map;
      var x = 27.61928, y = 85.53860;
      
           
     function kugate(){
		 x = 27.620701;
      	 y = 85.538376;
     }

     function docse(){
		 x = 27.620040; 
      	 y = 85.538958;
     }
   	
   	function civil(){
   		x= 27.619298;
   		y= 85.538074  ;
    }

    function electrical(){
   		x= 27.619615;
   		y= 85.539446;
    }

    function mechanical(){
   		x= 27.619741;
   		y= 85.539352;
    }

    function chemical(){
   		x= 27.619960;
   		y= 85.539124;
    }


    function pharmacy(){
   		x= 27.618942;
   		y= 85.538063;
    }

    function biotech(){
   		x= 27.619327;
   		y= 85.539494;
    }

    function cafe(){
   		x= 27.618517;
   		y= 85.538349;
    }

    function bank(){
   		x= 27.617388;
   		y= 85.539205;
    }

    function fountain(){
   		x= 27.618669;
   		y= 85.538591;
    }

    function admin(){
   		x= 27.619779;
   		y= 85.538596;
    }

    function football(){
   		x= 27.618695;
   		y= 85.536995;
    }

    function pool(){
   		x= 27.619408;
   		y= 85.536760;
    }

    function boyshostel(){
   		x= 27.617761;
   		y= 85.536700;
    }

    function girlshostel(){
   		x= 27.618139;
   		y= 85.539294;
    }

    function canteen(){
   		x= 27.619241;
   		y= 85.538991;
    }

    function library(){
   		x= 27.619037;
   		y= 85.538578;
    }

    function auditorium(){
   		x= 27.619350;
   		y= 85.538948;
    }

    function photocopy(){
   		x= 27.618999;
   		y= 85.538884;
    }

    function isms(){
   		x= 27.618951;
   		y= 85.538736;
    }

    function drawing(){
   		x= 27.620047;
   		y= 85.537304;
    }

    function social(){
   		x= 27.617792;
   		y= 85.536322;
    }

    function park(){
   		x= 27.617778;
   		y= 85.537400;
    }

    function staff(){
   		x= 27.617687;
   		y= 85.539385;
    }

    function workshop(){
   		x= 27.619973;
   		y= 85.537460;
    }

    function math(){
   		x= 27.618598;
   		y= 85.539683;
    }

    function bbis(){
   		x= 27.619412;
   		y= 85.537937;
    }

    function gym(){
   		x= 27.617483;
   		y= 85.535762;
    }

   
      	  		
      function initMap() {

	        map = new google.maps.Map(document.getElementById('map'), {    
	            center: {lat: 27.6189, lng: 85.5386},
	            zoom: 17,
	            mapTypeId: google.maps.MapTypeId.SATELLITE
	      	});

	      	
  		var kucentre = new google.maps.LatLng(x,y);
    

        var marker = new google.maps.Marker({
        	
    		position: kucentre,
    		    		
  		});

  		marker.setMap(map);

  		google.maps.event.addListener(marker,'click',function() { // zooms when clicked on location icon
		    map.setZoom(20);
		    map.setCenter(marker.getPosition());
		    window.setTimeout(function() {map.setZoom(17);},2000); //removes zoom after 2 sec and shows 17 zoom stage
		 	
		 	// var infowindow = new google.maps.InfoWindow({
    //   		content:"Its Admin Building"
    // 		});
 			// infowindow.open(map,marker);
 		});
 	

    }
   	
   