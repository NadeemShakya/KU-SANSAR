<?php 

require 'dbh.php';
session_start();

$QuestionNumber = $_GET['QuestionNumber'];
$sql = "DELETE FROM questions WHERE Question_ID = '$QuestionNumber'";
$result = mysqli_query($connection, $sql);
if($result){
	echo "<script>alert('Post Deleted');</script> ";
	header("Refresh:0.2; url=main.php");
}else{
	echo "<script>alert('Cannot Delete Post');</script> ";
	header("refresh:0.2; url=main.php");
}



 ?>