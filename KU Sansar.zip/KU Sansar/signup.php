<?php
include 'dbh.php';
//defining variables;
$firstnameError = $lastnameError = $studentIdError = $emailError = $passwordError = $cpasswordError = $msg = "";
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$studentId = $_POST['studentId'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	if($password != $cpassword){
		$cpasswordError = "Password Doesn't Match. Please try again.";

	}else{
		$statement = "INSERT INTO student VALUES('$firstname', '$lastname', '$studentId', '$email', '$password')";
		$result = mysqli_query($connection, $statement);
		$msg = "SingUp Successful !!";
		
	}

}

?>