<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "utf-8">
	<meta name = "viewport" content = "width = device-width, initial-scale = 1">
	<link rel="icon" href="images/title_img.png">
	<title>KU SANSAR</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="bootstrap/css/main.css">
	<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">

</head>
<?php 
require 'dbh.php';
$firstnameError = $lastnameError = $studentIdError = $emailError = $passwordError = $cpasswordError = $signupmsg = $loginMessage = "";


if($_SERVER['REQUEST_METHOD'] == "POST"){
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	$studentYear = $_POST['Year'];
	$studentSemester = $_POST['Semester'];
	$studentDepartment = $_POST['Department'];
	$studentRoll = $_POST['roll'];
	$studentID = $studentYear . "-" . $studentSemester ."-". $studentDepartment ."-".$studentRoll ;

	if($password != $cpassword){
		$cpasswordError = "Password Doesn't Match. Please try again.";

	}else{
		$statement = "INSERT INTO student VALUES('$firstname', '$lastname', '$studentID', '$email', '$password', '$studentYear', '$studentSemester', '$studentDepartment', '$studentRoll')";
		$result = mysqli_query($connection, $statement);
		$signupmsg = "SingUp Successful. Your StudentID is" ."  ".  $studentID;

	}
}



?>


<body>

		<nav class = "navbar-default fixed-top mainNavbar ">
			<div class = "container-fluid">
			<div class = "col-sm-12">
				<div class = "col-sm-7">
					<div class = "navbar-header">
						<a href="index.html" class = "navbar-brand headername"><h2>KU SANSAR</h2></a>
					</div>
				</div>
				<form action = "login.php" method = "POST">
					<div class = "col-sm-2 loginfield">	
						<div class = "form-group">
							<label for="StudentID">StudentID:</label>
							<input type="text" class = "form-control" placeholder = "StudentID" name = "login_stdID" required>
							<h4 style = "padding:5px; color:red;"><?php echo $loginMessage ?></h4>
						</div>

					</div>


					<div class = "col-sm-2 loginfield">
						<div class = "form-group">
							<label for="Password">Password:</label>
							<input type="password" class = "form-control" placeholder = "Password" name = "login_pswd" required>
						</div>
					</div>

					<br>
					<div class = "col-sm-1 loginbutton">
						<button type = "submit" class = "btn btn-success loginbutton">LogIn</button>
					</div>
					
					
				</form>
				
			</div>
			</div>
		</nav>	

			<!-- Start LeftWrapper -->
			<div class = "col-sm-4 leftWrapper"> 

			<form method = 'POST' action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

				<div class = "container-fluid">	
					<nav class = "navbar navbar-default">
						<div class = "navbar-header signUpNavBar">
							<h4>SignUp</h4>
						<h4 style = "color:#02b875;"> <?php echo $signupmsg ?> </h4>
							
						</div>
					</nav>
					<div class = "row">
						<div class = "col-sm-6">
							<label for="First Name">FirstName:</label>
							<input type="text" class = "form-control" id = "frstname" placeholder = "FirstName" name = "firstname" required>
							<?php echo $firstnameError ?>
						</div>
						<div class = "col-sm-6">
							<label for="Last Name">LastName</label>
							<input type="text" class = "form-control" id = "lastname" placeholder = "LastName" name = "lastname" required>
						</div>
					</div>
						<br>
					<div class = "form-group">
							<div class = "col-sm-3" style = "margin-left: -15px; ">
								<label for="Year">Year</label>
								<select name="Year" id="year">
									<option value = "1">First</option>
									<option value = "2">Second</option>

								</select>
							</div>
							<div class = "col-sm-3">
								<label for = "Semester">Semester</label>
								<select name = "Semester" id = "semester">
									<option value = "1">First</option>
									<option value = "2">Second</option>
								</select>
							</div>
							<div class = " col-sm-2">
								<label for="Roll"> Roll</label>
								<select name="roll" id="roll">
									<?php for($i=1;$i<=70;$i++):?>
										<option value="<?php echo $i ?>"><?php echo $i ?></option>
									<?php endfor; ?>
								</select>
							</div>
							<div class = "col-sm-3">
								<label for="Department">Department</label>
								<select name="Department" id="department">
									<option value="Computer">Computer</option>
									<option value="Civil">Civil</option>
									<option value="Electrical">Electrical</option>
								</select>
							</div>
						
					</div>
					<br><br><br>
					<div class = "form-group">
						<label for="Email">Email:</label>
						<input type="email" class = "form-control" id = "email" placeholder = "Email Id" name = "email" required>
					</div>
					<div class = "form-group">
						<label for="Password">Password:</label>
						<input type="password" class = "form-control" id = "password" placeholder = "Password" name = "password" min = "1" max = "13" required>
					</div>
					<div class = "form-group">
						<label for="Password">Confirm Password:</label>
						<input type="password" class = "form-control" id = "cpassword" placeholder = "Confirm Password" name = "cpassword" required><br>
						<h4 style = "color:red"><?php echo $cpasswordError;?></h4>
					</div>

					<button type = "submit" class = "btn btn-success">Create Account</button>
				</div>

			</form>

			</div> <!-- End Of Left Wrapper -->
	

		<div class = "col-sm-6 rightWrapper"> <!--Start of RightWrapper -->
			<div class = "row">
				<div class = "col-sm-4">
					<a href="#">
						<div class = "thumbnail">
							<img src="images/forum.png" alt="please_reload">
							<div class = "caption">DISCUSSION FORUM</div>
						</div>
					</a>
				</div>
				<div class = "col-sm-4">
					<a href="GPAcalcMain.html" "> 
						<div class = "thumbnail">
							<img src="images/calculator.png" alt="please_reload">
							<div class = "caption">GPA CALCULATOR</div>

						</div>
					</a>
				</div>
				<div class = "col-sm-4">
					<a href="fullcalendar/demos/calendarevent.html"> 
						<div class = "thumbnail">
							<img src="images/calendar.png" alt="please_reload">
							<div class = "caption">CALENDAR</div>
						</div>
					</a>
				</div>	

			</div>

			<div class = "row">
				<div class = "col-sm-4">
					<a href="techNews.html"> 
						<div class = "thumbnail">
							<img src="images/comments.png" alt="please_reload">
							<div class = "caption">TECH NEWS</div>
						</div>
					</a>

				</div>
				<div class = "col-sm-4">
					<a href="googlekumain.html" target = "_blank"> 
						<div class = "thumbnail">
							<img src="images/maps.png" alt="please_reload">
							<div class = "caption">GOOGLE KU</div>
						</div>
					</a>

				</div>
				<div class = "col-sm-4">
					<a href="news.html"> 
						<div class = "thumbnail">
							<img src="images/news.png" alt="please_reload">
							<div class = "caption">NEWS</div>
						</div>
					</a>

				</div>
			</div>

			<div class = "row">
				<div class = "col-sm-4">
					<a href="books/selectdepartment.html" target="_blank">
						<div class = "thumbnail">
							<img src="images/bookshelf.png" alt="please_reload">
							<div class = "caption">Books</div>
						</div>
					</a>
				</div>
				<div class = "col-sm-4">
					<a href="projects/selectdepartment.html">
						<div class = "thumbnail">
							<img src="images/projects.png" alt="please_reload">
						<div class = "caption">Semester Projects</div>
						</div>
					</a>
				</div>
				<div class = "col-sm-4">
					<a href="faq.php">
						<div class = "thumbnail">
							<img src="images/FAQ.png" alt="please_reload">
							<div class = "caption">FAQ</div>
						</div>
					</a>
				</div>

			</div>

		</div> <!-- End of Right Wrapper -->


		<div class = "col-sm-12 footer">
			<div class = "container-fluid">Website Developed and Maintained KU SANSAR <br>&copy; 2017 All Rights Reserved <br> Kathmandu, Nepal </div>
		</div>

	<form action="email.php" method = "POST">
		<!-- <button>Submit</button> -->
	</form>


</body>
<script type = "text/javascript" src = "main.js">

</script>
</html>


