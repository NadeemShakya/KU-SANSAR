<?php
	include 'dbh.php';
	session_start();
	$Student_ID = $_SESSION['Student_ID'];


?>
<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "utf-8">
	<meta name = "viewport" content = "width = device-width, initial-scale = 1">
	<link rel="icon" href="images/title_img.png">
	<title>KU SANSAR</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="bootstrap/css/discussionmain.css">
	<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">

</head>

<body>
		<nav class = "navbar-default fixed-top mainNavbar ">
			<div class = "container-fluid">
			
				<div class = "col-sm-2">
					<div class = "navbar-header">
						<a href="index.html" class = "navbar-brand headername"><h4>KU SANSAR</h4></a>
					</div>
				</div>

				<div class = "col-sm-6 searchQuestion">

				</div>

				<div class = " col-sm-4 answerQuestion">
					<ul>
						<li><a href = "myQuestion.php">My Posts</a></li>

							<?php 
								$sql = "SELECT count(flag) AS notification FROM questions WHERE Student_ID = '$Student_ID' AND flag = 1";
								$result = mysqli_query($connection, $sql);
								$row = mysqli_fetch_assoc($result);
								

							 ?>
						<li><a href = "notification.php"><?php echo $row['notification'];?>-Notification<?php if($row['notification']> 1){
							echo "s";
							} ?> </a></li>
						<li><a href="logout.php">Logout, <?php echo $_SESSION['firstname'] ?></a></li>
						

					</ul>
				</div>


				
			</div>

		</nav>

		<div class = "col-sm-2 leftDiv">
			
		</div>
		
		<div class = "col-sm-8 midDiv">
			
			
			<div class = "col-sm-12 posts">
				<?php 
					
					$Date = date('y/m/d');
					$StudentID = $_SESSION['Student_ID'];
					$sqlq = "SELECT * FROM student NATURAL JOIN Questions WHERE Student_ID = '$Student_ID' AND flag = 1";
					$resultq = mysqli_query($connection, $sqlq);
					if(mysqli_num_rows($resultq) == 0){
						echo " <h4 style = 'text-align:center; margin:50px 0px; color:red; font-size:25px;'>No new notifications yet!</h4>";
					}else{
						while($rowq = mysqli_fetch_assoc($resultq)){
							$QuestionNumber = $rowq['Question_ID'];
							echo "<h4>" . $rowq['firstname'] . $rowq['lastname']."'s Question</h4><br><br> ";
							echo "<h4>" . $rowq['Question']. "</h4><br>";
							echo "<h6> Posted Date: " . $rowq['Dates'] . " At Time " .  $rowq['Post_time'] ."</h6><br> ";
							echo "<form action='PostDiscussion.php' method = 'POST'>";
								echo "<button class = 'btn btn-primary' name = 'Answer' value = '$QuestionNumber'>Answer</button>";
							echo "</form>";
							echo "<hr>";
						}
					}
					$sql = "UPDATE questions set flag = 0 WHERE Student_ID = '$Student_ID' ";
					$result = mysqli_query($connection, $sql);

					
				 ?>

				<div class = "col-sm-12 insertAnswer">
				
					
				</div>
			</div>
				

				
		</div>
		
		
		<div class = "col-sm-2 rightDiv">
	
		</div>

<script type = "text/javascript" src = "main.js"></script>
</body>
</html>