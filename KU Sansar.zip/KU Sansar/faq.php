<?php
	include 'dbh.php';
?>
<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "utf-8">
	<meta name = "viewport" content = "width = device-width, initial-scale = 1">
	<link rel="icon" href="images/title_img.png">
	<title>KU SANSAR</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="bootstrap/css/main.css">
	<!-- <link rel="stylesheet" href="bootstrap/css/faq.css"> -->
	<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
	<nav class = "navbar-default fixed-top mainNavbar ">
			<div class = "container-fluid">

				<div class = "col-sm-7">
					<div class = "navbar-header">
						<a href="index.html" class = "navbar-brand headername"><h2>KU SANSAR Help Center</h2></a>
					</div>
				</div>
				<form action = "login.php" method = "POST">
					<div class = "col-sm-2 loginfield">	
						<div class = "form-group">
							<label for="StudentID">StudentID:</label>
							<input type="text" class = "form-control" placeholder = "StudentID" name = "login_stdID" required>
						</div>

					</div>


					<div class = "col-sm-2 loginfield">
						<div class = "form-group">
							<label for="Password">Password:</label>
							<input type="password" class = "form-control" placeholder = "Password" name = "login_pswd" required>
						</div>
					</div>

					<br>
					<div class = "col-sm-1 loginbutton">
						<button type = "submit" class = "btn btn-success loginbutton">LogIn</button>
					</div>
				</form>
				
			</div>
	</nav>	

<style>
.quest {
    margin-top: 5px;
    margin-left: 400px;
    padding: 5px;
    background-color: black;
    border: 2px solid #666;
    border-radius: 10px;
    width: 500px;
    font-size: 20px;
    text-align: center;
    color: white;
}

.quest:hover{
 background-color: grey;
 color: white;
 border-radius: 5px;
 transition:.4s;
 text-decoration: none;
}

.answer {
    margin-top: 5px;
    margin-left: 200px;
    padding: 5px;
    background-color: white;
    border: 2px solid #666;
    border-radius: 10px;
    width: 900px;
    font-size: 15px;
    text-align: center;
    color: black;
}

.answer:hover{
 background-color: black;
 color: white;
 border-radius: 5px;
 transition:.4s;
 text-decoration: none;
}

</style>

<div class = "col-sm-12 faques">
	<?php
	$sql= "SELECT * FROM faq_question Natural JOIN faq_answer ";
	$ans=mysqli_query($connection,$sql);
	while($faq_question = mysqli_fetch_assoc($ans)){
				echo "<br>"."<div class=\"quest\">".$faq_question['Question']."</div>";
				echo "<br>"."<div class=\"answer\">".$faq_question['Answer']."</div>";
		}
	?>
</div>


	
	<div class = "col-sm-12 footer ">
		<div class = "container-fluid">Website Developed and Maintained KU SANSAR <br>&copy; 2017 All Rights Reserved <br> Kathmandu, Nepal </div>
	</div>
</body>
</html>