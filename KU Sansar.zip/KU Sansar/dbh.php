<?php

$connection = mysqli_connect("localhost", "root", "", "kusansar");

//error handler

if(!$connection){
	die("Connection Error!");
}

?>