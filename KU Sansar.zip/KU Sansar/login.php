<?php 
session_start();
include 'dbh.php'; 


$ustudentID = $_POST['login_stdID'];
$upassword = $_POST['login_pswd'];

$sql = "SELECT * FROM student WHERE Student_ID= '$ustudentID' and spassword = '$upassword'";
$result = mysqli_query($connection, $sql);

	if(!$row = mysqli_fetch_assoc($result)){

		echo "<script> alert('Invalid Login! Make Sure To Enter Correct Credentials.');</script>";
		header("Refresh:0.1; url = index.php");

	}else{
		
		$_SESSION['firstname'] = $row['firstname'];
		$_SESSION['lastname'] = $row['lastname'];
		$_SESSION['Student_ID'] = $row['Student_ID'];
		$_SESSION['year'] = $row['year'];
		$_SESSION['semester'] = $row['semester'];
		$_SESSION['department'] = $row['department'];
		header("Location:main.php");

	}



?>




