-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2017 at 02:45 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kusansar`
--

-- --------------------------------------------------------

--
-- Table structure for table `faq_answer`
--

CREATE TABLE `faq_answer` (
  `Question_id` int(11) DEFAULT NULL,
  `Answer` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq_answer`
--

INSERT INTO `faq_answer` (`Question_id`, `Answer`) VALUES
(1, 'To create a KU SANSAR account:\r\nGo to localhost/kunsar/index.php\r\nEnter your name, email , password, year, semester, roll.no and department.\r\nClick create account.\r\n\r\nIf you already have a KU SANSAR account, you can log into your account.\r\nNote: you must be enrolled at KU to create a KU SANSAR account.'),
(2, 'To log into your KU SANSAR account:\r\nMake sure no one else is logged into KU SANSAR on that computer\r\nTo log someone else out, click  at the top right of your KU SANSAR homepage and select Log Out\r\nGo to the top of localhost/kunsar/index.php and enter one of the following:\r\nStudentID: You can log in with StudentID that''s provided by KU SANSAR during SignUP\r\n\r\nEnter your password\r\nClick LogIn'),
(3, 'To know the answer is all correct:\r\nSee the number of votes in the answer.'),
(4, '\r\nTo get study materials:\r\nOpen localhost/kusansar/books.html and find the books you want.'),
(5, 'If you know your current password, you can change it:\r\nClick in the top right corner of localhost/kusansar/index.php and select Settings\r\nClick Security next to Change Password\r\nClick Save Changes\r\n\r\nIf you don''t know your current password, we can help you recover your account.\r\nContact Us immediately.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faq_answer`
--
ALTER TABLE `faq_answer`
  ADD KEY `Question_id` (`Question_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `faq_answer`
--
ALTER TABLE `faq_answer`
  ADD CONSTRAINT `faq_answer_ibfk_1` FOREIGN KEY (`Question_id`) REFERENCES `faq_question` (`Question_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
