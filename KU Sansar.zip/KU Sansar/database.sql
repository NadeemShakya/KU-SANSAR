-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2017 at 06:46 AM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kusansar`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `contact_number` bigint(20) NOT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `firstname`, `lastname`, `contact_number`, `email`) VALUES
('Bibek001', 'Bibek', 'K.C.', 9860613083, 'bibekKc@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `answer_id` int(6) NOT NULL,
  `Question_ID` int(6) NOT NULL,
  `Student_ID` varchar(25) NOT NULL,
  `answer_date` date DEFAULT NULL,
  `Answer` varchar(3000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`answer_id`, `Question_ID`, `Student_ID`, `answer_date`, `Answer`) VALUES
(10, 29, '2-2-Computer-46', '2017-07-25', 'The conduction angle from Class B Amplifier is 180.'),
(11, 29, '2-2-Computer-46', '2017-07-31', 'b n vhj b n vbn'),
(15, 58, '1-2-Civil-3', '2017-08-14', 'test answer!'),
(16, 60, '1-2-Civil-3', '2017-08-14', 'bhandari'),
(17, 60, '1-2-Civil-3', '2017-08-14', 'bhandarrrri'),
(18, 58, '1-2-Civil-3', '2017-08-14', 'answer!\r\n'),
(19, 60, '2-2-Computer-46', '2017-08-14', 'nice name!'),
(20, 41, '1-2-Civil-3', '2017-08-14', 'dont know!'),
(21, 60, '1-2-Civil-3', '2017-08-14', 'asdfadfasdfadsfasdfasdf'),
(22, 61, '1-2-Civil-3', '2017-08-14', 'ok');

-- --------------------------------------------------------

--
-- Table structure for table `downvote`
--

CREATE TABLE `downvote` (
  `Student_ID` varchar(25) DEFAULT NULL,
  `Question_ID` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downvote`
--

INSERT INTO `downvote` (`Student_ID`, `Question_ID`) VALUES
('2-2-Computer-24', 37),
('2-2-Computer-46', 29),
('2-2-Computer-46', 41);

-- --------------------------------------------------------

--
-- Table structure for table `faq_answer`
--

CREATE TABLE `faq_answer` (
  `Question_id` int(11) DEFAULT NULL,
  `Answer` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq_answer`
--

INSERT INTO `faq_answer` (`Question_id`, `Answer`) VALUES
(1, 'To create a KU SANSAR account:\r\nGo to localhost/kunsar/index.php\r\nEnter your name, email , password, year, semester, roll.no and department.\r\nClick create account.\r\n\r\nIf you already have a KU SANSAR account, you can log into your account.\r\nNote: you must be enrolled at KU to create a KU SANSAR account.'),
(2, 'To log into your KU SANSAR account:\r\nMake sure no one else is logged into KU SANSAR on that computer\r\nTo log someone else out, click  at the top right of your KU SANSAR homepage and select Log Out\r\nGo to the top of localhost/kunsar/index.php and enter one of the following:\r\nStudentID: You can log in with StudentID that\'s provided by KU SANSAR during SignUP\r\n\r\nEnter your password\r\nClick LogIn'),
(3, 'To know the answer is all correct:\r\nSee the number of votes in the answer.'),
(4, '\r\nTo get study materials:\r\nOpen localhost/kusansar/books.html and find the books you want.'),
(5, 'If you know your current password, you can change it:\r\nClick in the top right corner of localhost/kusansar/index.php and select Settings\r\nClick Security next to Change Password\r\nClick Save Changes\r\n\r\nIf you don\'t know your current password, we can help you recover your account.\r\nContact Us immediately.');

-- --------------------------------------------------------

--
-- Table structure for table `faq_question`
--

CREATE TABLE `faq_question` (
  `Question_id` int(11) NOT NULL,
  `Question` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq_question`
--

INSERT INTO `faq_question` (`Question_id`, `Question`) VALUES
(1, 'How to create an account in KU SANSAR ?'),
(2, 'How to log into KU SANSAR account ?'),
(3, 'How do I know the answer is all correct ?'),
(4, 'How do I get Study Materials ?'),
(5, 'How to reset the account\'s Password ?');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `Question_ID` int(6) NOT NULL,
  `Subject_Code` varchar(11) DEFAULT NULL,
  `Dates` date DEFAULT NULL,
  `Student_ID` varchar(25) DEFAULT NULL,
  `Question` varchar(2000) DEFAULT NULL,
  `Post_time` varchar(40) DEFAULT NULL,
  `file` varchar(500) DEFAULT NULL,
  `flag` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`Question_ID`, `Subject_Code`, `Dates`, `Student_ID`, `Question`, `Post_time`, `file`, `flag`) VALUES
(1, 'COMP204', '2017-07-19', '2-2-Computer-46', 'What is ku sansar?', '07:26:50', NULL, 0),
(28, 'EEEG202', '2017-04-16', '2-2-Computer-46', 'What is conduction angle for Class A Amplifier?', '01:05:23', NULL, 0),
(29, 'EEEG202', '2017-04-16', '2-2-Computer-24', 'What is conduction angle for Class B Amplifier?', '01:05:23', NULL, NULL),
(37, 'EEEG202', '2017-07-19', '2-2-Computer-46', 'What is a flip-flop?', NULL, NULL, 0),
(41, 'OTHERS', '2017-07-24', '2-2-Computer-46', 'Why is Earth Round?', NULL, NULL, 0),
(58, 'COMP206', '2017-08-12', '2-2-Computer-46', 'Q.1 ) Help me to solve this B+ tree question! 1.	Construct a B+ tree for the following set of key values. (2,3,5,7,11,17,19,23,29,31) Assume that the tree initially empty and values are added in ascending order. Construct B+ trees for the cases where the number of pointers that will fit in one node is as follows. â€¢	Four â€¢	Six â€¢	Eight.', NULL, 'B+tree.png', 0),
(60, 'COMP116', '2017-08-14', '1-2-Civil-3', 'ram', NULL, NULL, 0),
(61, 'MATH104', '2017-08-14', '1-2-Civil-3', 'check question!!', NULL, NULL, 0),
(62, 'OTHERS', '2017-08-15', '2-2-Computer-46', 'This is a sample question!', NULL, NULL, 0),
(63, 'MCSC202', '2017-08-15', '2-2-Computer-46', 'sample question', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `firstname` varchar(11) NOT NULL,
  `lastname` varchar(11) NOT NULL,
  `Student_ID` varchar(25) NOT NULL,
  `email` varchar(20) NOT NULL,
  `spassword` varchar(20) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `semester` varchar(5) DEFAULT NULL,
  `department` varchar(11) DEFAULT NULL,
  `roll` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`firstname`, `lastname`, `Student_ID`, `email`, `spassword`, `year`, `semester`, `department`, `roll`) VALUES
('Ram', 'Bhandari', '1-2-Civil-3', 'ram@gmail.com', 'ram', '1', '2', 'Civil', '3'),
('Sandip ', 'Dulal', '2-1-Computer-9', 'sandipdulal@gmail.co', 'sandip', '2', '1', 'Computer', '9'),
('Subish', 'Lacoul', '2-2-Computer-24', 'subish@gmail.com', 'subish', '2', '2', 'Computer', '24'),
('Nadeem ', 'Shakya', '2-2-Computer-46', 'shakya.nadim12@gmail', 'nadeem', '2', '2', 'Computer', '46'),
('Sandip', 'Dulal', '2-2-Computer-9', 'sandipdulal@gmail.co', 'sandip', '2', '2', 'Computer', '9');

-- --------------------------------------------------------

--
-- Table structure for table `upvote`
--

CREATE TABLE `upvote` (
  `Student_ID` varchar(25) DEFAULT NULL,
  `Question_ID` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upvote`
--

INSERT INTO `upvote` (`Student_ID`, `Question_ID`) VALUES
('2-2-Computer-46', 28),
('2-2-Computer-46', 1),
('2-2-Computer-24', 41),
('2-2-Computer-46', 37);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`answer_id`),
  ADD KEY `Student_ID` (`Student_ID`),
  ADD KEY `Question_ID` (`Question_ID`);

--
-- Indexes for table `downvote`
--
ALTER TABLE `downvote`
  ADD KEY `Student_ID` (`Student_ID`),
  ADD KEY `Question_ID` (`Question_ID`);

--
-- Indexes for table `faq_answer`
--
ALTER TABLE `faq_answer`
  ADD KEY `Question_id` (`Question_id`);

--
-- Indexes for table `faq_question`
--
ALTER TABLE `faq_question`
  ADD PRIMARY KEY (`Question_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`Question_ID`),
  ADD KEY `Student_ID` (`Student_ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Student_ID`);

--
-- Indexes for table `upvote`
--
ALTER TABLE `upvote`
  ADD KEY `Student_ID` (`Student_ID`),
  ADD KEY `Question_ID` (`Question_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `answer_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `Question_ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_2` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`),
  ADD CONSTRAINT `answers_ibfk_3` FOREIGN KEY (`Question_ID`) REFERENCES `questions` (`Question_ID`) ON DELETE CASCADE;

--
-- Constraints for table `downvote`
--
ALTER TABLE `downvote`
  ADD CONSTRAINT `downvote_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`),
  ADD CONSTRAINT `downvote_ibfk_2` FOREIGN KEY (`Question_ID`) REFERENCES `questions` (`Question_ID`) ON DELETE CASCADE;

--
-- Constraints for table `faq_answer`
--
ALTER TABLE `faq_answer`
  ADD CONSTRAINT `faq_answer_ibfk_1` FOREIGN KEY (`Question_id`) REFERENCES `faq_question` (`Question_id`);

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`);

--
-- Constraints for table `upvote`
--
ALTER TABLE `upvote`
  ADD CONSTRAINT `upvote_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`),
  ADD CONSTRAINT `upvote_ibfk_2` FOREIGN KEY (`Question_ID`) REFERENCES `questions` (`Question_ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
