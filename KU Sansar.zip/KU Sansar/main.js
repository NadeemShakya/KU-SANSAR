
// CONVERTER function

function converter(num){
	if(num == 'A'){
		num = 4;
	}
	else if(num == 'A-'){
		num = 3.7;
	}
	else if(num == 'B+'){
		num = 3.3;
	}
	else if(num == 'B'){
		num = 3.0;
	}
	else if(num == 'B-'){
		num = 2.7;
	}
	else if(num == 'C+'){
		num = 2.3;
	}
	else if(num == 'C'){
		num = 2.0;
	}
	else if(num == 'C-'){
		num = 1.7;
	}
	else if(num == 'D'){
		num = 1.0;
	}
	else{
		num = 0;
	}
	return num;

}


//END OF CONVRETER function


// COMPUTER ENGINEERING 2ND YEAR 1ST SEMESTER

var math208total, mcsc201total, eeeg202total, eeeg211total, comp202total, comp208total, comp206total;
function math208display(){
	var x = document.getElementById('math208').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	math208total = y*3; 
	if(math208total == 0){
		document.getElementById('math208field').style.color = "red";
		document.getElementById('math208field').innerHTML = "Fail";
	}else{
		document.getElementById('math208field').innerHTML = math208total;
	}
	

}

function mcsc201display(){
	var x = document.getElementById('mcsc201').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	mcsc201total = y *3;
	if(mcsc201total == 0){
		document.getElementById('mcsc201field').style.color = "red";
		document.getElementById('mcsc201field').innerHTML = "Fail";
	}else{
		document.getElementById('mcsc201field').innerHTML = mcsc201total;
	}
	
}

function eeeg202display(){
	var x = document.getElementById("eeeg202").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	eeeg202total = y*3; 
	if(eeeg202total == 0){
		document.getElementById('eeeg202field').style.color = "red";
		document.getElementById('eeeg202field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg202field').innerHTML = eeeg202total;
	}
	

}

function eeeg211display(){
	var x = document.getElementById("eeeg211").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	eeeg211total = y * 3;
	if(eeeg211total == 0){
		document.getElementById('eeeg211field').style.color = "red";
		document.getElementById('eeeg211field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg211field').innerHTML = eeeg211total;
	}
	
}
function comp202display(){
	var x = document.getElementById("comp202").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp202total = y * 3;
	if(comp202total == 0){
		document.getElementById('comp202field').style.color = "red";
		document.getElementById('comp202field').innerHTML = "Fail";
	}else{
		document.getElementById('comp202field').innerHTML = comp202total;
	}
	
}
function comp208display(){
	var x = document.getElementById("comp208").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp208total = y * 1;
	if(comp208total == 0){
		document.getElementById('comp208field').style.color = "red";
		document.getElementById('comp208field').innerHTML = "Fail";
	}else{
		document.getElementById('comp208field').innerHTML = comp208total;
	}
	
}
function comp206display(){
	var x = document.getElementById("comp206").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp206total = y * 2;
	if(comp206total == 0){
		document.getElementById('comp206field').style.color = "red";
		document.getElementById('comp206field').innerHTML = "Fail";
	}else{
		document.getElementById('comp206field').innerHTML = comp206total;
	}
	
}

function showtotal_CE_2y1s(){

	if(math208total != undefined && mcsc201total != undefined && eeeg202total != undefined && eeeg211total != undefined && comp202total != undefined && comp206total != undefined && comp208total != undefined){
			var GPAtotal = math208total + mcsc201total + 	eeeg211total + eeeg202total + comp202total + comp208total + comp206total;
			var GPAdisplay = GPAtotal / 18;	
			document.getElementById('GPAtotal').innerHTML = GPAtotal;
			document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay;
	}else{
		alert("Enter All Subjects' Credits!!");
	}
}

//COMPUTER ENGINEERING 2ND YEAR 1ST SEM

//1ST YEAR 1ST SEM

function math101display(){
	var x = document.getElementById('math101').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	math101total = y*3; 
	if(math101total == 0){
		document.getElementById('math101field').style.color = "red";
		document.getElementById('math101field').innerHTML = "Fail";
	}else{

		document.getElementById('math101field').innerHTML = math101total;
	}
	

}

function phys101display(){
	var x = document.getElementById('phys101').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	phys101total = y*3; 
	if(phys101total == 0){
		document.getElementById('phys101field').style.color = "red";
		document.getElementById('phys101field').innerHTML = "Fail";
	}else{

		document.getElementById('phys101field').innerHTML = phys101total;
	}
	

}

function chem101display(){
	var x = document.getElementById('chem101').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	chem101total = y*3; 
	if(chem101total == 0){
		document.getElementById('chem101field').style.color = "red";
		document.getElementById('chem101field').innerHTML = "Fail";
	}else{

		document.getElementById('chem101field').innerHTML = chem101total;
	}
	

}

function comp103display(){
	var x = document.getElementById('comp103').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp103total = y*2; 
	if(comp103total == 0){
		document.getElementById('comp103field').style.color = "red";
		document.getElementById('comp103field').innerHTML = "Fail";
	}else{

		document.getElementById('comp103field').innerHTML = comp103total;
	}
	

}

function engt101display(){
	var x = document.getElementById('engt101').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	engt101total = y*2; 
	if(engt101total == 0){
		document.getElementById('engt101field').style.color = "red";
		document.getElementById('engt101field').innerHTML = "Fail";
	}else{

		document.getElementById('engt101field').innerHTML = engt101total;
	}
	

}

function engg111display(){
	var x = document.getElementById('engg111').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	engg111total = y*3; 
	if(engg111total == 0){
		document.getElementById('engg111field').style.color = "red";
		document.getElementById('engg111field').innerHTML = "Fail";
	}else{

		document.getElementById('engg111field').innerHTML = engg111total;
	}
	

}

function edrg101display(){
	var x = document.getElementById('edrg101').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	edrg101total = y*2; 
	if(edrg101total == 0){
		document.getElementById('edrg101field').style.color = "red";
		document.getElementById('edrg101field').innerHTML = "Fail";
	}else{

		document.getElementById('edrg101field').innerHTML = edrg101total;
	}
	

}

function engg101display(){
	var x = document.getElementById('engg101').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	engg101total = y*2; 
	if(engg101total == 0){
		document.getElementById('engg101field').style.color = "red";
		document.getElementById('engg101field').innerHTML = "Fail";
	}else{

		document.getElementById('engg101field').innerHTML = engg101total;
	}
	

}

function showtotal_1y1s(){
	if(math101total != undefined && phys101total != undefined && chem101total != undefined && comp103total != undefined && engt101total != undefined && engg111total != undefined && edrg101total != undefined && engg101total != undefined){
		var GPAtotal = math101total + phys101total + chem101total + comp103total + engt101total + engg111total + edrg101total + engg101total;
			var GPAdisplay = GPAtotal / 20;	
			document.getElementById('GPAtotal').innerHTML = GPAtotal;
			document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay;
	}else{
		alert("Enter All Subjects' Credits!");
	}
}

//1ST YEAR 1ST SEM


// COMPUTER ENGINEERING 2ND YEAR 2ND SEM

var math207total, mcsc201total, eeeg202total, eeeg211total, comp202total, comp208total, comp206total;
function math207display(){
	var x = document.getElementById('math207').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	math207total = y*4; 
	if(math207total == 0){
		document.getElementById('math207field').style.color = "red";
		document.getElementById('math207field').innerHTML = "Fail";
	}else{

		document.getElementById('math207field').innerHTML = math207total;
	}
	

}

function mcsc202display(){
	var x = document.getElementById('mcsc202').selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	mcsc202total = y *3;
	if(mcsc202total == 0){
		document.getElementById('mcsc202field').style.color = "red";
		document.getElementById('mcsc202field').innerHTML = "Fail";
	}else{
		document.getElementById('mcsc202field').innerHTML = mcsc202total;
	}
}

function comp204display(){
	var x = document.getElementById("comp204").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp204total = y*3; 
	if(comp204total == 0){
		document.getElementById('comp204field').style.color = "red";
		document.getElementById('comp204field').innerHTML = "Fail";
	}else{
		document.getElementById('comp204field').innerHTML =comp204total;
	}


}

function comp231display(){
	var x = document.getElementById("comp231").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp231total = y * 3;
	if(comp231total == 0){
		document.getElementById('comp231field').style.color = "red";
		document.getElementById('comp231field').innerHTML = "Fail";
	}else{
		document.getElementById('comp231field').innerHTML =comp231total;
	}

}
function comp232display(){
	var x = document.getElementById("comp232").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp232total = y * 3;
	if(comp232total == 0){
		document.getElementById('comp232field').style.color = "red";
		document.getElementById('comp232field').innerHTML = "Fail";
	}else{
		document.getElementById('comp232field').innerHTML =comp232total;
	}

}

function comp207display(){
	var x = document.getElementById("comp207").selectedIndex;
	var y = document.getElementsByTagName("option")[x].value;
	y = converter(y);
	comp207total = y * 2;
	if(comp207total == 0){
		document.getElementById('comp207field').style.color = "red";
		document.getElementById('comp207field').innerHTML = "Fail";
	}else{
		document.getElementById('comp207field').innerHTML =comp207total;
	}

}

function showtotal_CE_2y2s(){

	if(math207total != undefined && mcsc202total != undefined && comp204total != undefined && comp231total != undefined && comp232total != undefined && comp207total != undefined){
			var GPAtotal = math207total + mcsc202total + comp204total + comp231total + comp232total + comp207total;
			var GPAdisplay = GPAtotal / 18;	
			document.getElementById('GPAtotal').innerHTML = GPAtotal;
			document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay;
	}else{
		alert("Enter All Subjects' Credits!!");
	}
}

//COMPUTER ENGINEERING 2ND YEAR 2ND SEM

//ENGINEERING 1ST YEAR 2ND SEM

var comp116total, engg112total, phys102total, engt102total, math104total, enve101total, edrg102total, engg102total ;

function COMP116display(){
	var x = document.getElementById('COMP116').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	comp116total = y * 3;
	if(comp116total == 0){
		document.getElementById('comp116field').style.color = "red";
		document.getElementById('comp116field').innerHTML = "Fail";
	}else{
		document.getElementById('comp116field').innerHTML = comp116total;
	}

}

function ENGG112display(){
	var x = document.getElementById('engg112').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	engg112total = y * 3;
	if(engg112total == 0){
		document.getElementById('engg112field').style.color = "red";
		document.getElementById('engg112field').innerHTML = "Fail";
	}else{
		document.getElementById('engg112field').innerHTML = engg112total; 
	}
}

function ENGT102display(){
	var x = document.getElementById('engt102').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	engt102total = y * 2;
	if(engt102total == 0){
		document.getElementById('engt102field').style.color = "red";
		document.getElementById('engt102field').innerHTML = "Fail";
	}else{
		document.getElementById('engt102field').innerHTML = engt102total; 
	}
}

function PHYS102display(){
	var x = document.getElementById('phys102').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	phys102total = y * 3;
	if(phys102total == 0){
		document.getElementById('phys102field').style.color = "red";
		document.getElementById('phys102field').innerHTML = "Fail";
	}else{
		document.getElementById('phys102field').innerHTML = phys102total; 
	}
}

function MATH104display(){
	var x = document.getElementById('math104').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	math104total = y * 3;
	if(math104total == 0){
		document.getElementById('math104field').style.color = "red";
		document.getElementById('math104field').innerHTML = "Fail";
	}else{
		document.getElementById('math104field').innerHTML = math104total; 
	}
}

function ENVE101display(){
	var x = document.getElementById('enve101').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	enve101total = y * 2;
	if(enve101total == 0){
		document.getElementById('enve101field').style.color = "red";
		document.getElementById('enve101field').innerHTML = "Fail";
	}else{
		document.getElementById('enve101field').innerHTML = enve101total; 
	}
}

function EDRG102display(){
	var x = document.getElementById('edrg102').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	edrg102total = y * 2;
	if(edrg102total == 0){
		document.getElementById('edrg102field').style.color = "red";
		document.getElementById('edrg102field').innerHTML = "Fail";
	}else{
		document.getElementById('edrg102field').innerHTML = edrg102total; 
	}
}

function ENGG102display(){
	var x = document.getElementById('engg102').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	engg102total = y * 2;
	if(engg102total == 0){
		document.getElementById('engg102field').style.color = "red";
		document.getElementById('engg102field').innerHTML = "Fail";
	}else{
		document.getElementById('engg102field').innerHTML = engg102total; 
	}
}


function showtotal_1y2s(){
	if(comp116total != undefined && engg112total != undefined && engt102total != undefined && phys102total != undefined && math104total != undefined && enve101total != undefined && edrg102total != undefined && engg102total != undefined){
			var GPAtotal =comp116total+ engg112total + engt102total + phys102total + math104total + enve101total + edrg102total + engg102total;
			var GPAdisplay = GPAtotal /20;	
			document.getElementById('GPAtotal').innerHTML = 	GPAtotal;
			document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay;
	}else{
		alert("Enter All Subjects' Credits!!");
	}

}

//ENGINEERING 1ST YEAR 2ND SEM

//ELECTRONIC ENGINEERING 2ND YEAR 1ST SEM

function eeeg207display(){
	var x = document.getElementById('eeeg207').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg207total = y * 3;
	if(eeeg207total == 0){
		document.getElementById('eeeg207field').style.color = "red";
		document.getElementById('eeeg207field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg207field').innerHTML = eeeg207total;
	}
}

function eeeg213display(){
	var x = document.getElementById('eeeg213').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg213total = y * 3;
	if(eeeg213total == 0){
		document.getElementById('eeeg213field').style.color = "red";
		document.getElementById('eeeg213field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg213field').innerHTML = eeeg213total;
	}
}

function eeeg217display(){
	var x = document.getElementById('eeeg217').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg217total = y * 1;
	if(eeeg217total == 0){
		document.getElementById('eeeg217field').style.color = "red";
		document.getElementById('eeeg217field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg217field').innerHTML = eeeg217total;
	}
}

function eeeg218display(){
	var x = document.getElementById('eeeg218').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg218total = y * 1;
	if(eeeg218total == 0){
		document.getElementById('eeeg218field').style.color = "red";
		document.getElementById('eeeg218field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg218field').innerHTML = eeeg218total;
	}
}

function eeeg205display(){
	var x = document.getElementById('eeeg205').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg205total = y * 1;
	if(eeeg205total == 0){
		document.getElementById('eeeg205field').style.color = "red";
		document.getElementById('eeeg205field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg205field').innerHTML = eeeg205total;
	}
}


function showtotal_EE_2y1s(){
	if(math207total != undefined && eeeg202total != undefined && eeeg211total != undefined && eeeg207total != undefined && eeeg213total != undefined && eeeg217total != undefined && eeeg218total != undefined && eeeg205total != undefined){
		GPAtotal = math207total + eeeg202total + eeeg211total + eeeg207total + eeeg213total + eeeg217total + eeeg218total + eeeg205total;
		GPAdisplay = GPAtotal / 19;
		document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay
		document.getElementById('GPAtotal').innerHTML = GPAtotal;

	}else{
		alert("Enter All Subjects' Credits!!");

	}
}

//ELECTRONIC ENGINEERING 2ND YEAR 1ST SEM

//ELECTRONIC ENGINEERING 2ND YEAR 2ND SEM

function eeeg214display(){
	var x = document.getElementById('eeeg214').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg214total = y * 3;
	if(eeeg214total == 0){
		document.getElementById('eeeg214field').style.color = "red";
		document.getElementById('eeeg214field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg214field').innerHTML = eeeg214total;
	}


}

function comp201display(){
	var x = document.getElementById('comp201').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	comp201total = y * 3;
	if(comp201total == 0){
		document.getElementById('comp201field').style.color = "red";
		document.getElementById('comp201field').innerHTML = "Fail";
	}else{
		document.getElementById('comp201field').innerHTML = comp201total;
	}


}

function eeeg215display(){
	var x = document.getElementById('eeeg215').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg215total = y * 3;
	if(eeeg215total == 0){
		document.getElementById('eeeg215field').style.color = "red";
		document.getElementById('eeeg215field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg215field').innerHTML = eeeg215total;
	}


}

function eeeg219display(){
	var x = document.getElementById('eeeg219').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg219total = y * 1;
	if(eeeg219total == 0){
		document.getElementById('eeeg219field').style.color = "red";
		document.getElementById('eeeg219field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg219field').innerHTML = eeeg219total;
	}


}

function eeeg220display(){
	var x = document.getElementById('eeeg220').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg220total = y * 1;
	if(eeeg220total == 0){
		document.getElementById('eeeg220field').style.color = "red";
		document.getElementById('eeeg220field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg220field').innerHTML = eeeg220total;
	}


}

function eeeg212display(){
	var x = document.getElementById('eeeg212').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
	eeeg212total = y * 2;
	if(eeeg212total == 0){
		document.getElementById('eeeg212field').style.color = "red";
		document.getElementById('eeeg212field').innerHTML = "Fail";
	}else{
		document.getElementById('eeeg212field').innerHTML = eeeg212total;
	}


}

function showtotal_EE_2y2s(){
	if(math208total != undefined && mcsc202total != undefined && eeeg214total != undefined && comp201total != undefined && eeeg215total != undefined && eeeg219total != undefined && eeeg220total != undefined && eeeg212total != undefined){
		GPAtotal = math208total + mcsc202total + eeeg214total + comp201total + eeeg215total + eeeg219total + eeeg220total + eeeg212total;
		GPAdisplay = GPAtotal / 19;
		document.getElementById('GPAtotal').innerHTML = GPAtotal;	
		document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay;
	}
}
//ELECTRONIC ENGINEERING 2ND YEAR 2ND SEM


//CIVIL ENGINEERING 2ND YEAR 1ST SEM
function math205display(){
	var x = document.getElementById('math205').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	math205total = y * 3;
	if (math205total == 0){
		document.getElementById('math205field').style.color = "red";
		document.getElementById('math205field').innerHTML = "Fail";
	}else{
		document.getElementById('math205field').innerHTML = math205total;
	}

}

function cieg201display(){
	var x = document.getElementById('cieg201').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg201total = y * 3;
	if (cieg201total == 0){
		document.getElementById('cieg201field').style.color = "red";
		document.getElementById('cieg201field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg201field').innerHTML = cieg201total;
	}


}

function cieg202display(){
	var x = document.getElementById('cieg202').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg202total = y * 3;
	if (cieg202total == 0){
		document.getElementById('cieg202field').style.color = "red";
		document.getElementById('cieg202field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg202field').innerHTML = cieg202total;
	}


}

function cieg203display(){
	var x = document.getElementById('cieg203').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg203total = y * 3;
	if (cieg203total == 0){
		document.getElementById('cieg203field').style.color = "red";
		document.getElementById('cieg203field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg203field').innerHTML = cieg203total;
	}

}

function cieg204display(){
	var x = document.getElementById('cieg204').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg204total = y * 3;
	if (cieg204total == 0){
		document.getElementById('cieg204field').style.color = "red";
		document.getElementById('cieg204field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg204field').innerHTML = cieg204total;
	}


}

function cieg205display(){
	var x = document.getElementById('cieg205').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg205total = y * 2;
	if (cieg205total == 0){
		document.getElementById('cieg205field').style.color = "red";
		document.getElementById('cieg205field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg205field').innerHTML = cieg205total;
	}


}

function showtotal_CV_2y1s(){
	if(math205total != undefined && math207total != undefined && cieg201total != undefined && cieg202total != undefined && cieg203total != undefined && cieg204total != undefined && cieg205total != undefined){
		GPAtotal = math205total + math207total + cieg201total + cieg202total + cieg203total + cieg204total + cieg205total ;
		GPAdisplay = GPAtotal /21;
		document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay
		document.getElementById('GPAtotal').innerHTML = GPAtotal;

	}else{
		alert("Enter All Subjects' Credits!!");

	}
}



//CIVIL ENGINEERING 2ND YEAR 1ST SEM

//CIVIL ENGINEERING @ND YEAR 2ND SEM
function cieg206display(){
	var x = document.getElementById('cieg206').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg206total = y * 3;
	if (cieg206total == 0){
		document.getElementById('cieg206field').style.color = "red";
		document.getElementById('cieg206field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg206field').innerHTML = cieg206total;
	}


}

function cieg207display(){
	var x = document.getElementById('cieg207').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg207total = y * 3;
	if (cieg207total == 0){
		document.getElementById('cieg207field').style.color = "red";
		document.getElementById('cieg207field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg207field').innerHTML = cieg207total;
	}


}

function cieg207display(){
	var x = document.getElementById('cieg207').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg207total = y * 3;
	if (cieg207total == 0){
		document.getElementById('cieg207field').style.color = "red";
		document.getElementById('cieg207field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg207field').innerHTML = cieg207total;
	}


}

function cieg208display(){
	var x = document.getElementById('cieg208').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg208total = y * 3;
	if (cieg208total == 0){
		document.getElementById('cieg208field').style.color = "red";
		document.getElementById('cieg208field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg208field').innerHTML = cieg208total;
	}


}

function cieg209display(){
	var x = document.getElementById('cieg209').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg209total = y * 3;
	if (cieg209total == 0){
		document.getElementById('cieg209field').style.color = "red";
		document.getElementById('cieg209field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg209field').innerHTML = cieg209total;
	}


}

function cieg210display(){
	var x = document.getElementById('cieg210').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	y = converter(y);
 	cieg210total = y * 2;
	if (cieg210total == 0){
		document.getElementById('cieg210field').style.color = "red";
		document.getElementById('cieg210field').innerHTML = "Fail";
	}else{
		document.getElementById('cieg210field').innerHTML = cieg210total;
	}


}

function showtotal_CV_2y2s(){
	if(mcsc202total != undefined && math208total != undefined && cieg206total != undefined && cieg207total != undefined && cieg208total != undefined && cieg209total != undefined && cieg210total != undefined){
		GPAtotal = mcsc202total + math208total + cieg206total + cieg207total + cieg208total + cieg209total + cieg210total ;
		GPAdisplay = GPAtotal /20;
		document.getElementById('GPAdisplayButton').innerHTML = GPAdisplay
		document.getElementById('GPAtotal').innerHTML = GPAtotal;

	}else{
		alert("Enter All Subjects' Credits!!");

	}
}


//CIVIL ENGINEERING 2ND YEAR 2ND SEM


//MAIN PAGE OF GPA CALCULATOR STARTS
function selectDepartment(){
	var x = document.getElementById('selectDepartment').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectDepartment').style.fontSize = "15px";
	document.getElementById('selectDepartment').style.color = "red";


	if(y == 1){
		selectedDepartment = "CE";
	}else if(y == 2){
		selectedDepartment = "CV";
	}else if(y == 3){
		selectedDepartment = "EE"
	}
}

function selectYear(){
	var x = document.getElementById('selectYear').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectYear').style.fontSize = "15px";
	document.getElementById('selectYear').style.color = "red";
	if(y == 1){
		selectedYear = "first";

	}else if( y == 2){
		selectedYear = "second";
	}
}

function selectsemester(){
	var x = document.getElementById('selectSem').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectSem').style.fontSize = "15px";
	document.getElementById('selectSem').style.color = "red";
	if(y == 1){
		selectedSem = "first";

	}else if( y == 2){
		selectedSem = "second";
	}	
}



function openCalculator(){
	if(selectedDepartment == "CE" && selectedYear == "second" && selectedSem == "first"){
		window.open("GPAcalc_2ndYear1stSem_CE.html");
	}else if(selectedDepartment == "CE" && selectedYear == "second" && selectedSem == "second"){
		window.open("GPAcalc_2ndYear2ndSem_CE.html");
	}else if(selectedDepartment == "CV" && selectedYear == "second" && selectedSem == "first"){
		window.open("GPAcalc_2ndYear1stSem_CV.html");

	}else if(selectedDepartment == "CV" && selectedYear == "second" && selectedSem == "second"){
		window.open("GPAcalc_2ndYear2ndSem_CV.html");

	}else if(selectedDepartment == "EE" && selectedYear == "second" && selectedSem == "first"){
		window.open("GPAcalc_2ndYear1stSem_EE.html");		

	}else if(selectedDepartment == "EE" && selectedYear == "second" && selectedSem == "second"){
		window.open("GPAcalc_2ndYear2ndSem_EE.html");
	}else if(selectedYear == "first" && selectedSem == "first"){
		window.open("GPAcalc_1stYear1stSem.html");

	}else if(selectedYear == "first" && selectedSem == "second"){
		window.open("GPAcalc_1stYear2ndSem.html");
	}
}

//MAIN PAGE OF GPA CALCULATOR ENDS

function openOptions(){
	document.getElementById('optionBoxId').style.display = "block";
}



