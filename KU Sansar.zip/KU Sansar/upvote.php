<?php 
include 'dbh.php';
session_start();
$QuestionNumber = $_POST['QuestionNumber'];
$Student_ID = $_SESSION['Student_ID'];

	$sql = "INSERT INTO upvote(Student_ID, Question_ID) values ('$Student_ID', '$QuestionNumber')";
	$sql1 = "SELECT * FROM upvote WHERE Student_ID = '$Student_ID' AND Question_ID = '$QuestionNumber'";
	$sql2 = "SELECT * FROM downvote WHERE Student_ID = '$Student_ID ' AND Question_ID = '$QuestionNumber'";
	$sql3 = "DELETE FROM downvote WHERE Student_ID = '$Student_ID' AND Question_ID = '$QuestionNumber'";
	$result2 = mysqli_query($connection, $sql2);	
	$result1 = mysqli_query($connection, $sql1);

	if(mysqli_num_rows($result1) == 0){
		if(mysqli_num_rows($result2) == 0){
		$result = mysqli_query($connection, $sql);
		echo "<script>alert('Vote Counted!');</script> ";
		header("Refresh:0.1; url = main.php");
		}else{
			
			$result3 = mysqli_query($connection, $sql3);
			$result = mysqli_query($connection, $sql);
			echo "<script>alert('Vote Counted!');</script> ";
			header("Refresh:0.1; url = main.php");
		}
	}else{
		echo "<script>alert('You Have Already Voted!');</script> ";
		header("Refresh:0.1; url = main.php");
	}





 ?>