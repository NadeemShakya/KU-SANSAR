<?php
	include 'dbh.php';
	session_start();
	$searchRequest = FALSE;
	$year = $_SESSION['year'];
	$department = $_SESSION['department'];
	$semester = $_SESSION['semester'];
	$Student_ID = $_SESSION['Student_ID'];
	if($_SERVER['REQUEST_METHOD'] == "POST"){
	$searchRequest = TRUE;

	}
		date_default_timezone_set("Asia/Kathmandu");
	$time = date('h:i:sa');



?>
<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "utf-8">
	<meta name = "viewport" content = "width = device-width, initial-scale = 1">
	<link rel="icon" href="images/title_img.png">
	<title>KU SANSAR</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="bootstrap/css/discussionmain.css">
	<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">


</head>

<body>
<!-- 
	<script type = "text/javascript">
		function nadim(){
			alert("hello world!");
		}
	</script> -->
		<nav class = "navbar-default fixed-top mainNavbar ">
			<div class = "container-fluid">
			
				<div class = "col-sm-2">
					<div class = "navbar-header">
						<a href="main.php" class = "navbar-brand headername"><h4>KU SANSAR</h4></a>
					</div>
				</div>

				<div class = "col-sm-6 searchQuestion">
					<ul>
						<li>
							<form method = 'POST' action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
								<input type="text" placeholder = "Search Your Queries With KU SANSAR..." name = "searchQuestion" required>
						</li>
						<li>
							<button class ="btn btn-default">Search</button>
								
						</li>
							</form>
					</ul>
				</div>

				<div class = " col-sm-4 answerQuestion">

					<ul>
						<li><a href = "myQuestion.php">My Posts</a></li>

							<?php 
								$sql = "SELECT count(flag) AS notification FROM questions WHERE Student_ID = '$Student_ID' AND flag = 1";
								$result = mysqli_query($connection, $sql);
								$row = mysqli_fetch_assoc($result);
								

							 ?>
						<li><a href = "notification.php"><?php echo "<h6 style = 'margin:0px; padding:0px; display:inline; color:red; font-size:17px;'>(" . $row['notification'] . ")</h6>";?> Notification<?php if($row['notification']> 1){
							echo "s";
							} ?> </a></li>
						<li><a href="logout.php">Logout</a></li>
						

					</ul>
				</div>
		


				
			</div>

		</nav>

		<div class = "col-sm-2 leftDiv">
			<h3>Handy Apps</h3>
			<ul>
				<a href="fullcalendar/demos/calendarevent.html"><li><img src="images/calendar.png" alt="please_reload"><br>Calendar</li></a>
				<a href="GPAcalcMain.html"><li><img src="images/calculator.png" alt="please_reload"><br>Calculator</li></a>
				<a href="googlekumain.html"><li><img src="images/maps.png" alt="please_reload"><br>Google KU</li></a>
				<a href="techNews.html"><li><img src="images/comments.png" alt="please_reload"><br>TechNews</li></a>
				<a href="books/selectdepartment.html"><li><img src="images/bookshelf.png" alt="please_reload"><br>Bookshelf<br></li></a>
			</ul>
		</div>
		
		<div class = "col-sm-8 midDiv">
			<div class = "col-sm-12" midDiv1>
			
			<br>
				<h5>Top Stories For You</h5>
				<hr>
			
					<?php 
						if(isset($_SESSION['firstname'])){
							echo "<label>" . $_SESSION['firstname'] . " " . $_SESSION['lastname'] . "'s Question" . "</label>";
						}
					 ?>
				<form action="insertQuestion.php" method = "POST" enctype = "multipart/form-data">
					<div class = "col-sm-10 postarea">
						<textarea name="post" placeholder = "What is your question <?php echo $_SESSION['firstname']; ?> ...?  "   required autofocus></textarea>

					</div>

					<div class = "col-sm-2">
						
						<button class = "btn btn-primary" name = "submit">POST</button>

					</div>
					<div class = "col-sm-12">
						<input type="file" name = "fileUpload" id = "fileUpload" ><br>	
						Question is Related to Subject Code : 
						<select name = "SubjectCode" required>
						<?php 
							if($_SESSION['year'] == 1 && $_SESSION['semester'] == 1){
								echo "
								<option value=\"\">Select</option>
								<option value=\"math101\">math101</option>
								<option value=\"phys101\">phys101</option>
								<option value=\"chem101\">chem101</option>
								<option value=\"comp103\">comp103</option>
								<option value=\"engt101\">engt101</option>
								<option value=\"engg111\">engg111</option>
								<option value=\"edrg101\">edrg101</option>
								<option value=\"engg101\">engg101</option>
								<option value=\"others\">Others</option>
								";
							}
							else if($_SESSION['year'] == 1 && $_SESSION['semester'] == 2){
								echo "
								<option value=\"\">Select</option>
								<option value=\"comp116\">comp116</option>
								<option value=\"engg112\">engg112</option>
								<option value=\"engt102\">engt102</option>
								<option value=\"phys102\">phys102</option>
								<option value=\"math104\">math104</option>
								<option value=\"enve101\">enve101</option>
								<option value=\"edrg102\">edrg102</option>
								<option value=\"others\">Others</option>
								";
							}
							
							else if($_SESSION['department'] == 'Computer' && $_SESSION['year'] == 2 && $_SESSION['semester'] == 1){
								echo "
								<option value=\"\">Select</option>
								<option value=\"math208\">math208</option>
								<option value=\"mcsc201\">mcsc201</option>
								<option value=\"eeeg202\">eeeg202</option>
								<option value=\"eeeg211\">eeeg211</option>
								<option value=\"comp202\">comp202</option>
								<option value=\"comp208\">comp208</option>
								<option value=\"comp206\">comp206</option>
								<option value=\"others\">Others</option>
								";
							}

							else if($_SESSION['department'] == 'Computer' && $_SESSION['year'] == 2 && $_SESSION['semester'] == 2){
								echo "
								<option value=\"\">Select</option>
								<option value=\"math207\">math207</option>
								<option value=\"mcsc202\">mcsc202</option>
								<option value=\"comp204\">comp204</option>
								<option value=\"comp231\">comp231</option>
								<option value=\"comp232\">comp232</option>
								<option value=\"comp207\">comp207</option>
								<option value=\"others\">Others</option>
								";
							}
							else if($_SESSION['department'] == 'Civil' && $_SESSION['year'] == 2 && $_SESSION['semester'] == 1){
								echo "
								<option value=\"\">Select</option>
								<option value=\"math205\">math205</option>
								<option value=\"math207\">math207</option>
								<option value=\"cieg201\">cieg201</option>
								<option value=\"cieg202\">cieg202</option>
								<option value=\"cieg203\">cieg203</option>
								<option value=\"cieg204\">cieg204</option>
								<option value=\"cieg205\">cieg205</option>
								<option value=\"others\">Others</option>
								";
							}

							else if($_SESSION['department'] == 'Civil' && $_SESSION['year'] == 2 && $_SESSION['semester'] == 2){
								echo "
								<option value=\"\">Select</option>
								<option value=\"mcsc202\">mcsc202</option>
								<option value=\"math208\">math208</option>
								<option value=\"cieg206\">cieg206</option>
								<option value=\"cieg207\">cieg207</option>
								<option value=\"cieg208\">cieg208</option>
								<option value=\"cieg209\">cieg209</option>								
								<option value=\"cieg210\">cieg210</option>
								<option value=\"others\">Others</option>
								";
							}
							else if($_SESSION['department'] == 'Electrical' && $_SESSION['year'] == 2 && $_SESSION['semester'] == 1){
								echo "
								<option value=\"\">Select</option>
								<option value=\"math207\">math207</option>
								<option value=\"eeeg202\">eeeg202</option>
								<option value=\"eeeg211\">eeeg211</option>
								<option value=\"eeeg207\">eeeg207</option>
								<option value=\"eeeg213\">eeeg213</option>
								<option value=\"eeeg217\">eeeg217</option>
								<option value=\"eeeg218\">eeeg218</option>
								<option value=\"eeeg205\">eeeg205</option>
								<option value=\"others\">Others</option>
								";
							}

							else if($_SESSION['department'] == 'Electrical' && $_SESSION['year'] == 2 && $_SESSION['semester'] == 2){
								echo "
								<option value=\"\">Select</option>
								<option value=\"math208\">math208</option>
								<option value=\"mcsc202\">mcsc202</option>
								<option value=\"comp201\">comp201</option>
								<option value=\"eeeg214\">eeeg214</option>
								<option value=\"eeeg215\">eeeg215</option>								
								<option value=\"eeeg219\">eeeg219</option>
								<option value=\"eeeg220\">eeeg220</option>
								<option value=\"eeeg212\">eeeg212</option>
								<option value=\"others\">Others</option>
								";
							}
						?>
						</select>
							
						<!-- <input type="submit" value = "fileUpload" name = "submit"> -->

					</div>

				</form>

				
			</div>
			
			<div class = "col-sm-12 postsOuterWrapper">

			<br>	
			<hr>	
			<h2>POSTS</h2>
		
				<?php 
				if($searchRequest == FALSE){	
					$sqlquestion = "SELECT * FROM Questions NATURAL JOIN student WHERE year = '$year' AND semester = '$semester' AND department = '$department' ORDER BY Question_ID desc";
					$resultquestion = mysqli_query($connection, $sqlquestion);
					$Serial_Number = 1;

					while($rowquestion = mysqli_fetch_assoc($resultquestion)){
						
						echo "<div class = 'col-sm-12 postsInnerWrapper '>";

						$QuestionNumber = $rowquestion['Question_ID'];
						$sqlupvote = "SELECT * FROM upvote WHERE Question_ID = '$QuestionNumber'";
						$result = mysqli_query($connection, $sqlupvote);
						$upvoteCount = mysqli_num_rows($result);
						
						$sqldownvote = "SELECT * FROM downvote WHERE Question_ID = '$QuestionNumber'";
						$result = mysqli_query($connection, $sqldownvote);
						$downvoteCount = mysqli_num_rows($result);
						
						
						
						echo "<h5>" . $rowquestion['firstname'] . $rowquestion['lastname'];
						if($rowquestion['Student_ID'] == $_SESSION['Student_ID']){	
							echo "<a href = 'deletePost.php?QuestionNumber=".$rowquestion['Question_ID']."'><button class = 'btn btn-danger' style = 'float:right;'>Delete </button></a> ";
						}
						echo "</h5>" 
						. "<br>";
						

						echo "<h4> Q." .$Serial_Number . " ) " . $rowquestion['Question']. "</h4><br>";
						if($rowquestion['file'] != NULL){
							echo "<img src=".'uploads/' . $rowquestion['file']." class = 'imagepost' alt ='please_reload'>";
						}

						echo "<h6> Posted Date: " . $rowquestion['Dates'] . " At time " .  $rowquestion['Post_time'] ."</h6>"; 
						$Serial_Number ++;
						echo "<form action='PostDiscussion.php' method = 'POST'>";
							echo "<button class = 'btn btn-primary' name = 'Answer' value = '$QuestionNumber'>Answer</button>";
						echo "</form>";
						echo "<form action = 'upvote.php' method = 'POST'>";
							echo "<button class = 'btn btn-success' name = 'QuestionNumber' value = '$QuestionNumber'>Upvote</button> (" . $upvoteCount.")";
						echo "</form>";
						echo "<form action = 'downvote.php' method = 'POST'>";
							echo "<button class = 'btn btn-danger' name = 'QuestionNumber' value = '$QuestionNumber'>Downvote</button> (" . $downvoteCount . ") <br><br>";
						echo "</form>";
					

						echo "<div class = 'col-sm-12 answerBox'>" 
							.
							"<form action = 'insertAnswer.php' method = 'POST'>".
								"<textarea name = 'answer' placeholder = 'Write your answer...' autofocus></textarea>".
								"<div class = 'col-sm-12 answerBoxFooter'>
								<button class = 'btn btn-primary' value = '$QuestionNumber' name = 'submit'>Submit</button>
								
							</div>". 
							"</form>".
							"</div>";
						echo "Answers: <br><br>";

						$sqlanswer = "SELECT * FROM Answers NATURAL JOIN student WHERE Question_ID = '$QuestionNumber'";
						$resultanswer = mysqli_query($connection, $sqlanswer);
						if(mysqli_num_rows($resultanswer) == 0){
							echo "No Answers Yet. <hr>";				
						}
						$counter = 1;
						while($rowanswer = mysqli_fetch_assoc($resultanswer)){
							
							if($counter <= 10){
								echo "<h5>" . $rowanswer['firstname'] . $rowanswer['lastname']. "</h5>" . "<br>";
								echo "<h6>Answered On: " . $rowanswer['answer_date']  ."</h6>";
								echo "- " . $rowanswer['Answer'];
								echo "<hr>";
								$counter++;
							}

						}

						echo "</div>";

					}

					$sqlquestion1 = "SELECT * FROM Questions NATURAL JOIN student WHERE year != '$year' OR semester != '$semester' OR department != '$department' ORDER BY Question_ID desc";
					$resultquestion1 = mysqli_query($connection, $sqlquestion1);
					while($rowquestion = mysqli_fetch_assoc($resultquestion1)){
						echo "<div class = 'col-sm-12 postsInnerWrapper '>";

						$QuestionNumber = $rowquestion['Question_ID'];
						$sqlupvote = "SELECT * FROM upvote WHERE Question_ID = '$QuestionNumber'";
						$result = mysqli_query($connection, $sqlupvote);
						$upvoteCount = mysqli_num_rows($result);
						
						$sqldownvote = "SELECT * FROM downvote WHERE Question_ID = '$QuestionNumber'";
						$result = mysqli_query($connection, $sqldownvote);
						$downvoteCount = mysqli_num_rows($result);
						
						
						
						echo "<h5>" . $rowquestion['firstname'] . $rowquestion['lastname'];
						if($rowquestion['Student_ID'] == $_SESSION['Student_ID']){	
							echo "<a href = 'deletePost.php?QuestionNumber=".$rowquestion['Question_ID']."'><button class = 'btn btn-danger' style = 'float:right;'>Delete </button></a> ";
						}
						echo "</h5>" 
						. "<br>";
						

						echo "<h4> Q." .$Serial_Number . " ) " . $rowquestion['Question']. "</h4><br>";
						if($rowquestion['file'] != NULL){
							echo "<img src=".'uploads/' . $rowquestion['file']." class = 'imagepost' alt ='please_reload'>";
						}
						echo "<h6> Posted Date: " . $rowquestion['Dates'] . " At time " .  $rowquestion['Post_time'] ."</h6>"; 
						$Serial_Number ++;
						echo "<form action='PostDiscussion.php' method = 'POST'>";
							echo "<button class = 'btn btn-primary' name = 'Answer' value = '$QuestionNumber'>Answer</button>";
						echo "</form>";
						echo "<form action = 'upvote.php' method = 'POST'>";
							echo "<button class = 'btn btn-success' name = 'QuestionNumber' value = '$QuestionNumber'>Upvote</button> (" . $upvoteCount.")";
						echo "</form>";
						echo "<form action = 'downvote.php' method = 'POST'>";
							echo "<button class = 'btn btn-danger' name = 'QuestionNumber' value = '$QuestionNumber'>Downvote</button> (" . $downvoteCount . ") <br><br>";
						echo "</form>";
					

						echo "<div class = 'col-sm-12 answerBox'>" 
							.
							"<form action = 'insertAnswer.php' method = 'POST'>".
								"<textarea name = 'answer' placeholder = 'Write your answer...' autofocus></textarea>".
								"<div class = 'col-sm-12 answerBoxFooter'>
								<button class = 'btn btn-primary' value = '$QuestionNumber' name = 'submit'>Submit</button>
								
							</div>". 
							"</form>".
							"</div>";
						echo "Answers: <br><br>";

						$sqlanswer = "SELECT * FROM Answers NATURAL JOIN student WHERE Question_ID = '$QuestionNumber'";
						$resultanswer = mysqli_query($connection, $sqlanswer);
						if(mysqli_num_rows($resultanswer) == 0){
							echo "No Answers Yet. <hr>";				
						}
						$counter = 1;
						while($rowanswer = mysqli_fetch_assoc($resultanswer)){
							
							if($counter <= 10){
								echo "<h5>" . $rowanswer['firstname'] . $rowanswer['lastname']. "</h5>" . "<br>";
								echo "<h6>Answered On: " . $rowanswer['answer_date']  ."</h6>";
								echo "- " . $rowanswer['Answer'];
								echo "<hr>";
								$counter++;
							}

						}

						echo "</div>";
					}

				}else{
						if($_SERVER['REQUEST_METHOD'] == "POST"){
							
							$Question = $_POST['searchQuestion'];
							$sql = "SELECT * FROM questions NATURAL JOIN student WHERE Question like '%$Question%'";
							$result = mysqli_query($connection, $sql);
							if(mysqli_num_rows($result) == 0){

								echo "<h4>Sorry No Matches!</h4>";
							}else{
							while($row = mysqli_fetch_assoc($result)){
								
								$QuestionNumber = $row['Question_ID'];
								$sqlupvote = "SELECT * FROM upvote WHERE Question_ID = '$QuestionNumber'";
								$result1 = mysqli_query($connection, $sqlupvote);
								$upvoteCount = mysqli_num_rows($result1);
								
								$sqldownvote = "SELECT * FROM downvote WHERE Question_ID = '$QuestionNumber'";
								$result2 = mysqli_query($connection, $sqldownvote);
								$downvoteCount = mysqli_num_rows($result2);
								$Serial_Number = 1;
								echo "<h5>" . $row['firstname'] . $row['lastname']. "</h5>" . "<br>";
								echo "<h4> Q." .$Serial_Number . " ) " . $row['Question']. "</h4><br>";
								if($row['file'] != NULL){
									echo "<img src=".'uploads/' . $row['file']." class = 'imagepost' alt ='please_reload'>";
								}
								echo "<h6> Posted Date: " . $row['Dates'] . " At time " .  $row['Post_time'] ."</h6>";
								$Serial_Number ++;
								echo "<form action='PostDiscussion.php' method = 'POST'>";
									echo "<button class = 'btn btn-primary' name = 'Answer' value = '$QuestionNumber'>Answer</button>";
								echo "</form>";
								echo "<form action = 'upvote.php' method = 'POST'>";
									echo "<button class = 'btn btn-success'>Upvote</button> (" . $upvoteCount . ")";
								echo "</form>";
								echo "<form action = 'downvote.php' method = 'POST'>";
									echo "<button class = 'btn btn-danger'>Downvote</button> (" . $downvoteCount. ")";
								echo "</form><br>";

								echo "<div class = 'col-sm-12 answerBox'>" 
								.
									"<form action = 'insertAnswer.php' method = 'POST'>".
									"<textarea name = 'answer' placeholder = 'Write your answer...' autofocus></textarea>".
									"<div class = 'col-sm-12 answerBoxFooter'>
										<button class = 'btn btn-primary' value = '$QuestionNumber' name = 'submit'>Submit</button>
									
									</div>". 
									"</form>"
								.
								"</div>";
								$sqlanswer = "SELECT * FROM Answers NATURAL JOIN student WHERE Question_ID = '$QuestionNumber'";
								$resultanswer = mysqli_query($connection, $sqlanswer);
								if(mysqli_num_rows($resultanswer) == 0){
									echo "No Answers Yet. <hr>";				
								}	
								while($rowanswer = mysqli_fetch_assoc($resultanswer)){
									echo "<h5>" . $rowanswer['firstname'] . $rowanswer['lastname']. "</h5>" . "<br>";
									echo "<h6>Answered On: " . $rowanswer['answer_date']  ."</h6>";
									echo "- " . $rowanswer['Answer'];
									echo "<hr>";
								}
								
							}
						}



						}
				}

				 ?>
			
				<form action = "">
					
				</form>
			</div>
				

			
				
		</div>
		
		
		<div class = "col-sm-2 rightDiv">
			<?php 
			echo "<div class = 'rightDivChild'>
				<h5>Related Courses</h5> <hr>";
				if($year == 1 && $semester == 1){

					echo "	

						<ul>
							<li><a href='individual.php?code=math101'>MATH 101</a></li>
							<li><a href='individual.php?code=phys101'>PHYS 101</a></li>
							<li><a href='individual.php?code=chem101'>CHEM 101</a></li>
							<li><a href='individual.php?code=comp103'>COMP 103</a></li>
							<li><a href='individual.php?code=engt101'>ENGT 101</a></li>
							<li><a href='individual.php?code=engg111'>ENGG 111</a></li>
							<li><a href='individual.php?code=edrg101'>EDRG 101</a></li>
							<li><a href='individual.php?code=engg101'>ENGG 101</a></li>
						</ul>
				
					";
				}else if($year ==1 && $semester == 2){
					echo "
						<ul>
							<li><a href='individual.php?code=comp116'>COMP 116</a></li>
							<li><a href='individual.php?code=engg112'>ENGG 112</a></li>
							<li><a href='individual.php?code=engt102'>ENGT 102</a></li>
							<li><a href='individual.php?code=phys102'>PHYS 102</a></li>
							<li><a href='individual.php?code=math104'>MATH 104</a></li>
							<li><a href='individual.php?code=enve101'>ENVE 101</a></li>
							<li><a href='individual.php?code=edrg102'>EDRG 102</a></li>
							<li><a href='individual.php?code=engg102'>ENGG 102</a></li>
						</ul>
				
					";
				}else if($year == 2 && $semester == 1 && $department == 'Computer'){
					echo "
						<ul>
							<li><a href='individual.php?code=comp116'>COMP 116</a></li>
							<li><a href='individual.php?code=engg112'>ENGG 112</a></li>
							<li><a href='individual.php?code=engt102'>ENGT 102</a></li>
							<li><a href='individual.php?code=phys102'>PHYS 102</a></li>
							<li><a href='individual.php?code=math104'>MATH 104</a></li>
							<li><a href='individual.php?code=enve101'>ENVE 101</a></li>
							<li><a href='individual.php?code=edrg102'>EDRG 102</a></li>
							<li><a href='individual.php?code=engg102'>ENGG 102</a></li>
						</ul>
				
					";
				}else if($year == 2 && $semester == 1 && $department == 'Computer'){
					echo "
						<ul>
							<li><a href='individual.php?code=math208'>MATH 208</a></li>
							<li><a href='individual.php?code=mcsc 201'>MCSC 201</a></li>
							<li><a href='individual.php?code=eeeg 202'>EEEG 202</a></li>
							<li><a href='individual.php?code=eeeg 211'>EEEG 211</a></li>
							<li><a href='individual.php?code=eeeg 211'>COMP 202</a></li>
							<li><a href='individual.php?code=comp 208'>COMP 208</a></li>
							<li><a href='individual.php?code=comp 206'>COMP 206</a></li>
						</ul>
				
					";
				}else if($year == 2 && $semester == 2 && $department == 'Computer'){
					echo "
						<ul>
							<li><a href='individual.php?code=math 207'>MATH 207</a></li>
							<li><a href='individual.php?code=mcsc 202'>MCSC 202</a></li>
							<li><a href='individual.php?code=comp 204'>COMP 204</a></li>
							<li><a href='individual.php?code=comp 231'>COMP 231</a></li>
							<li><a href='individual.php?code=comp 232'>COMP 232</a></li>
							<li><a href='individual.php?code=comp 207'>COMP 207</a></li>
						</ul>
				
					";
				}else if($year == 2 && $semester == 1 && $department == 'Civil'){
					echo "
						<ul>
							<li><a href='individual.php?code=math 205'>MATH 205</a></li>
							<li><a href='individual.php?code=math 207'>MATH 207</a></li>
							<li><a href='individual.php?code=cieg 201'>CIEG 201</a></li>
							<li><a href='individual.php?code=cieg 202'>CIEG 202</a></li>
							<li><a href='individual.php?code=cieg 203'>CIEG 203</a></li>
							<li><a href='individual.php?code=cieg 204'>CIEG 204</a></li>
							<li><a href='individual.php?code=cieg 205'>CIEG 205</a></li>
						</ul>
				
					";
				}else if($year == 2 && $semester == 2 && $department == 'Civil'){
					echo "
						<ul>
							<li><a href='individual.php?code=mcsc 202'>MCSC 202</a></li>
							<li><a href='individual.php?code=math 208'>MATH 208</a></li>
							<li><a href='individual.php?code=cieg 206'>CIEG 206</a></li>
							<li><a href='individual.php?code=cieg 207'>CIEG 207</a></li>
							<li><a href='individual.php?code=cieg 208'>CIEG 208</a></li>
							<li><a href='individual.php?code=cieg 209'>CIEG 209</a></li>
							<li><a href='individual.php?code=cieg 210'>CIEG 210</a></li>
						</ul>
				
					";
				}else if($year == 2 && $semester == 1 && $department == 'Electrical'){
					echo "
						<ul>
							<li><a href='individual.php?code=math 207'>MATH 207</a></li>
							<li><a href='individual.php?code=eeeg 202'>EEEG 202</a></li>
							<li><a href='individual.php?code=eeeg 211'>EEEG 211</a></li>
							<li><a href='individual.php?code=eeeg 207'>EEEG 207</a></li>
							<li><a href='individual.php?code=eeeg 213'>EEEG 213</a></li>
							<li><a href='individual.php?code=eeeg 217'>EEEG 217</a></li>
							<li><a href='individual.php?code=eeeg 218'>EEEG 218</a></li>
							<li><a href='individual.php?code=eeeg 205'>EEEG 205</a></li>
						</ul>
				
					";
				}else if($year == 2 && $semester == 2 && $department == 'Electrical'){
					echo "
						<ul>
							<li><a href='individual.php?code=math 208'>MATH 208</a></li>
							<li><a href='individual.php?code=mcsc 202'>MCSC 202</a></li>
							<li><a href='individual.php?code=eeeg 214'>EEEG 214</a></li>
							<li><a href='individual.php?code=comp 201'>COMP 201</a></li>
							<li><a href='individual.php?code=eeeg 215'>EEEG 215</a></li>
							<li><a href='individual.php?code=eeeg 219'>EEEG 219</a></li>
							<li><a href='individual.php?code=eeeg 220'>EEEG 220</a></li>
							<li><a href='individual.php?code=eeeg 212'>EEEG 212</a></li>
						</ul>
				
					";
				}

			echo "</div>";
			 ?>
		</div>
<script type = "text/javascript" src = "main.js"></script>
</body>
</html>