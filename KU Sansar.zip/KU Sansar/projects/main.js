function selectDepartment(){
	var x = document.getElementById('selectDepartment').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectDepartment').style.fontSize = "15px";
	document.getElementById('selectDepartment').style.color = "red";


	if(y == 1){
		selectedDepartment = "CE";
	}else if(y == 2){
		selectedDepartment = "CV";
	}else if(y == 3){
		selectedDepartment = "EE"
	}
}

function selectYear(){
	var x = document.getElementById('selectYear').selectedIndex;
	var y = document.getElementsByTagName('option')[x].value;
	document.getElementById('selectYear').style.fontSize = "15px";
	document.getElementById('selectYear').style.color = "red";
	if(y == 1){
		selectedYear = "first";

	}else if( y == 2){
		selectedYear = "second";
	}
}




function openCalculator(){
	 if(selectedDepartment == "CE" && selectedYear == "first"){
		window.open("COMP1_2.html");
	}
	
	else if(selectedDepartment == "CE" && selectedYear == "second"){
		window.open("COMP2_2.html");
	}
	
	else if(selectedDepartment == "CV" && selectedYear == "first"){
		window.open("CIVIL1_2.html");
	}
	
	else if(selectedDepartment == "CV" && selectedYear == "second"){
		window.open("CIVIL2_2.html");
	}
	
	else if(selectedDepartment == "EE" && selectedYear == "first"){
		window.open("ELECT1_2.html");
	}
	
	else if(selectedDepartment == "EE" && selectedYear == "second"){
		window.open("ELECT2_2.html");
	}
	

}