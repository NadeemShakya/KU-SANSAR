<?php 

require 'dbh.php';
session_start();

$Question_ID = $_POST['submit'];
$answers = $_POST['answer'];
$Student_ID = $_SESSION['Student_ID'];
$date = date('Y/m/d');
date_default_timezone_set("Asia/Kathmandu");
echo "The time is " . date("h:i:sa");


$sql = "INSERT INTO answers( Question_ID, Student_ID, answer_date, Answer) VALUES ('$Question_ID', '$Student_ID', '$date', '$answers')";
$sql1 = "UPDATE questions SET flag = 1 WHERE Question_ID = '$Question_ID'";
$result1 = mysqli_query($connection, $sql1);
$result = mysqli_query($connection, $sql);
echo "<script>alert(\"Answer Posted Successfully.\")</script> ";
header("Refresh:0.1; url = main.php");



?>